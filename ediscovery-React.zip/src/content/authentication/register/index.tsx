import {Box, Typography, Hidden, Container, Grid} from '@mui/material';
import TextField from '@mui/material/TextField';
import { Helmet } from 'react-helmet-async';

import { styled } from '@mui/material/styles';
import Button from '@mui/material/Button';
import { Navigate } from 'react-router-dom';

import React, { useReducer, useEffect, useState } from 'react';
import 'src/style.css';
import 'src/http-common.ts';

// Compare differemnt  approaches of adding styles to material ui componenets

const GridWrapper = styled(Grid)(
  ({ theme }) => `
    background: ${theme.colors.gradients.black1};
`
);


const TypographyPrimary = styled(Typography)(
  ({ theme }) => `
      color: ${theme.colors.alpha.white[100]};
`
);

const TypographySecondary = styled(Typography)(
  ({ theme }) => `
      color: ${theme.colors.alpha.white[70]};
`
);


//state type
// eslint -- enforce coding stand
type State = {
  username: string
  email: string
  password:  string
  isButtonDisabled: boolean
  helperText: string
  isError: boolean
};

const initialState:State = {
  username: '',
  email: '',
  password: '',
  isButtonDisabled: true,
  helperText: '',
  isError: false
};

type Action = { type: 'setusername' | 'setemail' | 'setPassword' | 'loginSuccess' | 'loginFailed', payload: string }
| { type: 'setIsButtonDisabled' | 'setIsError', payload: boolean };

const reducer = (state: State, action: Action): State => {
  switch (action.type) {
    case 'setemail': 
      return {
        ...state,
        email: action.payload
      };
    case 'setusername': 
      return {
        ...state,
        username: action.payload
      };
    case 'setPassword': 
      return {
        ...state,
        password: action.payload
      };
    case 'setIsButtonDisabled': 
      return {
        ...state,
        isButtonDisabled: action.payload
      };
    case 'loginSuccess': 
      return {
        ...state,
        helperText: action.payload,
        isError: false
      };
    case 'loginFailed': 
      return {
        ...state,
        helperText: action.payload,
        isError: true
      };
    case 'setIsError': 
      return {
        ...state,
        isError: action.payload
      };
  }
}


function LoginUser() {

  const [books, setBooks] = useState(null);

  // Fetch data on button click

  // const apiURL = "https://www.anapioficeandfire.com/api/books?pageSize=30";

  // const fetchData = async () => {
  //   const response = await axios.get(apiURL)

  //   setBooks(response.data) 
  // }


  //Make API request and display on load

  // + adding the use
  useEffect(() => {
    getData();

    // we will use async/await to fetch this data
    async function getData() {
      const response = await fetch("https://www.anapioficeandfire.com/api/books");
      const data = await response.json();
      console.log(data);

      // store the data into our books variable
      setBooks(data) ;
    }
  }, []);


  const [pending, setPending] = useState(false);
  function handleClick() {
    setPending(true);
  }
  const [state, dispatch] = useReducer(reducer, initialState);


  
  useEffect(() => {
    if (state.username.trim() && state.email.trim() && state.password.trim()) {
     dispatch({
       type: 'setIsButtonDisabled',
       payload: false
     });
    } else {
      dispatch({
        type: 'setIsButtonDisabled',
        payload: true
      });
    }
  }, [state.username, state.email, state.password]);

  const handleLogin = () => {
    if (state.username === 'admin' && state.email === 'admin@gmail.com' && state.password === 'admin') {
      dispatch({
        type: 'loginSuccess',
        payload: 'Login Successfully',
      });
     return (<Navigate
            to="/login"
          />);
      // return <Redirect to="/dashboards/crypto" />

      localStorage.setItem('email' , state.email);

      //this.props.history.push('/dashboards/crypto');

      //window.location.href = "/dashboards/crypto";

    }
    
    // else if (state.username === '' || state.email === '' || state.password === '') {
    //   dispatch({
    //     type: 'loginFailed',
    //     payload: 'Please fill requried fields'
    //   });
    // }
    
    else {
      dispatch({
        type: 'loginFailed',
        payload: 'Incorrect email or password'
      });
    }
  };

  const handleKeyPress = (event: React.KeyboardEvent) => {
    if (event.keyCode === 13 || event.which === 13) {
      state.isButtonDisabled || handleLogin();
    }
  };

  const handleusernameChange: React.ChangeEventHandler<HTMLInputElement> =
    (event) => {
      dispatch({
        type: 'setusername',
        payload: event.target.value
        
      });
    };

  const handleemailChange: React.ChangeEventHandler<HTMLInputElement> =
    (event) => {
      dispatch({
        type: 'setemail',
        payload: event.target.value
        
      });
    };
    

  const handlePasswordChange: React.ChangeEventHandler<HTMLInputElement> =
    (event) => {
      dispatch({
        type: 'setPassword',
        payload: event.target.value
      });
    }

  return (
    <>

      
      <Helmet>
        <title>Inabia - ediscovery</title>
      </Helmet>
      <div className='main-content'>
        <Grid
          container
          sx={{ height: '100%' }}
          alignItems="stretch"
          spacing={0}
        >
          
          <Hidden mdDown>
            <GridWrapper
              xs={12}
              md={6}
              alignItems="center"
              display="flex"
              className='login-bg'
              justifyContent="center"
              item
            >
              
              
              <Container maxWidth="lg" >
                <Box textAlign="left">
                  <TypographyPrimary variant="h1" sx={{ my: 1}}
                  fontSize="40px"
                  fontWeight="lighter"
                  letterSpacing="1px">
                  Welcome to 
                  </TypographyPrimary>
                  
                  <TypographyPrimary variant="h1" sx={{ my: 1 }}
                  fontSize="40px"
                  letterSpacing="1px"
                  >
                  <b>INABIA EBOT</b>
                  </TypographyPrimary>
                  <TypographySecondary
                    variant="h4"
                    fontWeight="normal"
                    sx={{ mb: 4 }}
                    color="#fff"
                  >
                    
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua
                  </TypographySecondary>
                  
                </Box>
              </Container>
              
            </GridWrapper>
    
          </Hidden>

          <Grid
            xs={12}
            md={6}
            alignItems="center"
            display="flex"
            justifyContent="center"
            item
          >
            <Container maxWidth="sm">
            
            <form  noValidate autoComplete="off">

              <Box textAlign="center">
                <img
                  alt="500"
                  height={80}
                  src="/static/images/inabia_ai_logo.png"
                />
                <br></br>
                <br></br>
    
                <Typography variant="h2" sx={{ my: 1 }}>

                <TextField
                      error={state.isError}
                      fullWidth
                      id="username"
                      type="username"
                      label="Username"
                      placeholder="Umail"
                      margin="normal"
                      onChange={handleusernameChange}
                      onKeyPress={handleKeyPress}
                      autoComplete="current-username"
                      sx={{ mb: 2, width:'60%' }}
                    />
                
                <br></br>  
                
                <TextField
                      error={state.isError}
                      fullWidth
                      id="email"
                      type="email"
                      label="Email"
                      placeholder="Email"
                      margin="normal"
                      onChange={handleemailChange}
                      onKeyPress={handleKeyPress}
                      autoComplete="current-email"
                      sx={{ mb: 2, width:'60%' }}
                    />
                
                <br></br>

                <TextField
                      error={state.isError}
                      fullWidth
                      id="password"
                      type="password"
                      label="Password"
                      placeholder="Password"
                      margin="normal"
                      helperText={state.helperText}
                      onChange={handlePasswordChange}
                      onKeyPress={handleKeyPress}
                      autoComplete="current-password"
                      sx={{ mb: 2, width:'60%' }}
                    />

                </Typography>
                
                {/* <LoadingButton
                  onClick={handleClick}
                  loading={pending}
                  variant="outlined"
                  color="primary"
                  startIcon={<RefreshTwoToneIcon />}
                >
                  Refresh view
                </LoadingButton> */}
                <Button 
                variant="contained"
                sx={{ mb: 2 }}
                //className={classes.loginBtn}
                className ="loginbtn"
                onClick={handleLogin}
                disabled={state.isButtonDisabled}
                >
                  Signin
                </Button>
                <Typography variant="h6" sx={{ my: 1 }}>
                  Already have a account login now, <a href="/"
                  color="red" 
                  >Signin</a>
                </Typography>
              </Box>
              </form>
            </Container>
          </Grid>
        </Grid>
      </div>
               

    </>
  );
}

export default LoginUser;
